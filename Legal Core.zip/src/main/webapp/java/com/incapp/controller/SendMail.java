package com.incapp.controller;

import java.util.HashMap;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
public class SendMail  {
	
	public static void mailSend(String email,String subject,String msg) {
			//send mail code:
			try {
				String senderEmail="abhinavchahal8384@gmail.com";
				String senderPassword="iutcdiafonzuxrlt";
				String sub=subject;
				String body=msg;
				Properties properties = new Properties();  
				properties.put("mail.smtp.host", "smtp.gmail.com");
	        	properties.put("mail.smtp.port", "465");
	        	properties.put("mail.smtp.ssl.enable", "true");
	        	properties.put("mail.smtp.auth", "true");
				
	            Session ses=Session.getInstance(properties,

	                    new javax.mail.Authenticator() {

	                        protected PasswordAuthentication getPasswordAuthentication(){

	                            return new PasswordAuthentication(senderEmail,senderPassword);

	                        }

	                    }

	                    );

	            Message message=new MimeMessage(ses);

	            message.setFrom(new InternetAddress(senderEmail));

	            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email));

	            message.setSubject(sub);

	            message.setContent(body,"text/html" );



	            Transport.send(message);
	            
	            Transport.send(message);
			}catch (Exception e) {
				e.printStackTrace();
			}
			//send mail code: Ends

	}

}
