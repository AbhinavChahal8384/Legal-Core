package com.incapp.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.incapp.model.DAO;

/**
 * Servlet implementation class AdminLogin
 */
@WebServlet("/UpdateStatus")
public class UpdateStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String email=request.getParameter("email");
			String status=request.getParameter("status");
			DAO d=new DAO();
			if(status.equalsIgnoreCase("active")) {
				int activationCode=(int)(Math.random()*9000+1000);
				d.setActivationCode(email, activationCode);
				
				//send mail code:
				SendMail.mailSend(email,"Activation Code for LegalCore App.", "Your Activation Code form Legal Core is "+activationCode);
				//send mail code: Ends
				
				response.sendRedirect("AdminHome.jsp");
			}else {
				String type=request.getParameter("type");
				d.updateStatus(email,status,type);
				d.setActivationCode(email, 0);
				response.sendRedirect("AdminHome.jsp");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

}
