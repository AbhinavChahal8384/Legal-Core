package com.incapp.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.incapp.model.DAO;


@WebServlet("/Feedback")
public class Feedback extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // Retrieve the form data
	
    // Do something with the form data (e.g. store it in a database)
   
   try {
	   String useremail=request.getParameter("user_email");
		String username=request.getParameter("user_name");
		String advocateemail=request.getParameter("advocate_email");
		String advocatename=request.getParameter("advocate_name");
	   String feedback = request.getParameter("feedback");
	   int rating = Integer.parseInt(request.getParameter("rating"));
		DAO d=new DAO();
		String result=d.addfeedback(advocateemail, advocatename, username, useremail, rating, feedback);
		if(result.equalsIgnoreCase("success")) {
			HttpSession session=request.getSession();
			session.setAttribute("msg","Your Feedback Sent Successfully!");
			response.sendRedirect("index.jsp");
		}
		else {
			HttpSession session=request.getSession();
			session.setAttribute("msg","Your Feedback Sent Failed!");
			response.sendRedirect("index.jsp");
		}
		
	}catch (Exception e) {
		e.printStackTrace();
	}
    
    // Display a confirmation message
    response.getWriter().println("Thank you for your feedback!");
  }

}
