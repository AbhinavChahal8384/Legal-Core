package com.incapp.controller;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.incapp.model.DAO;

/**
 * Servlet implementation class AdminLogin
 */
@WebServlet("/ForgetPassword")
public class ForgetPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String type=request.getParameter("type");
			String email=request.getParameter("email");
			DAO d=new DAO();
			String password=d.getPassword(email,type);
			
			//send mail code:
			SendMail.mailSend(email,"Password for LegalCore App.", "Your Email ID: "+email+" . Your Password: "+password);
			//send mail code: Ends

			HttpSession session=request.getSession();
			session.setAttribute("msg","Password Sent Successfully!");
			if(type.equalsIgnoreCase("user")) {
				response.sendRedirect("User.jsp");
			}
			else {
				response.sendRedirect("Advocate.jsp");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

}
